Python 3.7.3 (default, Jan 22 2021, 20:04:44) 
[GCC 8.3.0] on linux
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=========== RESTART: /home/kc/Computer Assignments/Assignment 2.py ===========
Length of given string is 35
Reverse of given string is:  egaugnal evitisnes esac a si nohtyP
Sliced string is:  a case sensitive
New string is:  Python is object oriented language
Index of "a" in string is:  10
Given string without white spaces:  Pythonisacasesensitivelanguage
Hey Kalash here! 
My SID is 21105115 
I am from ECE and my cgpa is 9.900000
a&b is  8
a|b is  58
a^b is  50
Left Shifting "a" with 2 bits  224  and "b" with 2 bits  40
Right Shifting "a" with 2 bits 14  and "b" with 4 bits  0
Enter 1st number: 65
Enter 2nd number: 33
Enter 3rd number: 65
Greatest of 3 numbers is:  65
Enter a string: name
True
Enter length of 1st side: 43
Enter length of 2nd side: 34
Enter length of 3rd side: 88
No
>>> 
